﻿global using ZLinq;
