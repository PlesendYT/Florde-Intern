using System.Diagnostics;
using Godot;
using Microsoft.Extensions.Logging;
using SharpIDE.Application.Features.Analysis;
using SharpIDE.Application.Features.Build;
using SharpIDE.Application.Features.Evaluation;
using SharpIDE.Application.Features.Events;
using SharpIDE.Application.Features.FilePersistence;
using SharpIDE.Application.Features.FileSystem;
using SharpIDE.Application.Features.FileWatching;
using SharpIDE.Application.Features.NavigationHistory;
using SharpIDE.Application.Features.SolutionDiscovery;
using SharpIDE.Application.Features.SolutionDiscovery.VsPersistence;
using SharpIDE.Godot.Features.CodeEditor;
using SharpIDE.Godot.Features.CustomControls;
using SharpIDE.Godot.Features.Run;
using SharpIDE.Godot.Features.Search;
using SharpIDE.Godot.Features.Search.SearchAllFiles;
using SharpIDE.Godot.Features.SolutionExplorer;
using SharpIDE.Godot.Features.ToolPanes;

namespace SharpIDE.Godot;

public partial class IdeRoot : Control
{
	public IdeWindow IdeWindow { get; set; } = null!;
	private Button _openSlnButton = null!;
	private Button _buildSlnButton = null!;
	private Button _rebuildSlnButton = null!;
	private Button _cleanSlnButton = null!;
	private Button _restoreSlnButton = null!;
	private TextureButton _cancelMsBuildActionButton = null!;
	private SearchWindow _searchWindow = null!;
	private SearchAllFilesWindow _searchAllFilesWindow = null!;
	private CodeEditorPanel _codeEditorPanel = null!;
	private InvertedVSplitContainer _invertedVSplitContainer = null!;

	private TaskCompletionSource _nodeReadyTcs = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);

	[Inject] private readonly FileChangedService _fileChangedService = null!;
	[Inject] private readonly IdeFileExternalChangeHandler _fileExternalChangeHandler = null!;
	[Inject] private readonly IdeFileWatcher _fileWatcher = null!;
	[Inject] private readonly BuildService _buildService = null!;
    [Inject] private readonly IdeOpenTabsFileManager _openTabsFileManager = null!;
    [Inject] private readonly RoslynAnalysis _roslynAnalysis = null!;
    [Inject] private readonly SharpIdeRootFolderModificationService _rootFolderModificationService = null!;
    [Inject] private readonly SharpIdeSolutionAccessor _sharpIdeSolutionAccessor = null!;
    [Inject] private readonly IdeNavigationHistoryService _navigationHistoryService = null!;
    [Inject] private readonly SharpIdeSolutionService _sharpIdeSolutionService = null!;
    [Inject] private readonly ILogger<IdeRoot> _logger = null!;

	public override void _EnterTree()
	{
		GodotGlobalEvents.Instance = new GodotGlobalEvents();
		GlobalEvents.Instance = new GlobalEvents();
	}

	public override void _ExitTree()
	{
		_fileWatcher?.Dispose();
		GetTree().GetRoot().FocusExited -= OnFocusExited;
	}

	public override void _Ready()
	{
		_openSlnButton = GetNode<Button>("%OpenSlnButton");
		_buildSlnButton = GetNode<Button>("%BuildSlnButton");
		_rebuildSlnButton = GetNode<Button>("%RebuildSlnButton");
		_cleanSlnButton = GetNode<Button>("%CleanSlnButton");
		_restoreSlnButton = GetNode<Button>("%RestoreSlnButton");
		_cancelMsBuildActionButton = GetNode<TextureButton>("%CancelMsBuildActionButton");
		_codeEditorPanel = GetNode<CodeEditorPanel>("%CodeEditorPanel");
		_searchWindow = GetNode<SearchWindow>("%SearchWindow");
		_searchAllFilesWindow = GetNode<SearchAllFilesWindow>("%SearchAllFilesWindow");
		_invertedVSplitContainer = GetNode<InvertedVSplitContainer>("%InvertedVSplitContainer");
		GodotGlobalEvents.Instance.FileSelected.Subscribe(OnSolutionExplorerPanelOnFileSelected);
		_openSlnButton.Pressed += () => IdeWindow.PickSolution();
		_buildSlnButton.Pressed += OnBuildSlnButtonPressed;
		_rebuildSlnButton.Pressed += OnRebuildSlnButtonPressed;
		_cleanSlnButton.Pressed += OnCleanSlnButtonPressed;
		_restoreSlnButton.Pressed += OnRestoreSlnButtonPressed;
		_cancelMsBuildActionButton.Pressed += async () => await _buildService.CancelBuildAsync();
		_buildService.BuildStarted.Subscribe(OnBuildStarted);
		_buildService.BuildFinished.Subscribe(OnBuildFinished);
		GetTree().GetRoot().FocusExited += OnFocusExited;
		_nodeReadyTcs.SetResult();
	}

	private async Task OnBuildStarted(BuildStartedFlags flags) => await OnBuildRunningStateChanged(true, flags);
	private async Task OnBuildFinished() => await OnBuildRunningStateChanged(false);
	private async Task OnBuildRunningStateChanged(bool running, BuildStartedFlags? flags = null)
	{
		if (running && flags is BuildStartedFlags.UserFacing) GodotGlobalEvents.Instance.ToolPaneExternallyActivated.InvokeParallelFireAndForget(ToolPaneType.Build);
		await this.InvokeAsync(() =>
		{
			_cancelMsBuildActionButton.Disabled = !running;
			_buildSlnButton.Disabled = running;
			_rebuildSlnButton.Disabled = running;
			_cleanSlnButton.Disabled = running;
			_restoreSlnButton.Disabled = running;
		});
	}

	// TODO: Problematic, as this is called even when the focus shifts to an embedded subwindow, such as a popup
	private void OnFocusExited()
	{
		if (Debugger.IsAttached is false)
		{
			_ = Task.GodotRun(async () => await _openTabsFileManager.SaveAllOpenFilesAsync());
		}
	}

	private void OnBuildSlnButtonPressed() => MsBuild(BuildType.Build);
	private void OnRebuildSlnButtonPressed() => MsBuild(BuildType.Rebuild);
	private void OnCleanSlnButtonPressed() => MsBuild(BuildType.Clean);
	private void OnRestoreSlnButtonPressed() => MsBuild(BuildType.Restore);
	private async void MsBuild(BuildType buildType)
	{
		await Task.CompletedTask.ConfigureAwait(ConfigureAwaitOptions.ForceYielding);
		await _buildService.MsBuildAsync(_sharpIdeSolutionAccessor.SolutionModel.FilePath, buildType);
	}

	private async Task OnSolutionExplorerPanelOnFileSelected(SharpIdeFile file, SharpIdeFileLinePosition? fileLinePosition)
	{
		await _codeEditorPanel.SetSharpIdeFile(file, fileLinePosition);
		_navigationHistoryService.RecordNavigation(file, fileLinePosition ?? new SharpIdeFileLinePosition(0, 0));
	}

	public void SetSlnFilePath(string path)
	{
		_ = Task.GodotRun(async () =>
		{
			GD.Print($"Selected: {path}");
			var timer = Stopwatch.StartNew();
			var sharpIdeRootFolder = await FileSystemService.GetSharpIdeRootFolderForSolutionAsync(path);
			ProjectEvaluation.ClearLoadedProjects();
			var (solutionModel, vsSln, solutionSerializer) = await SharpIdeSolutionService.ReadSolution(path, sharpIdeRootFolder);
			timer.Stop();
			await _nodeReadyTcs.Task;
			// Do not use injected services until after _nodeReadyTcs - Services aren't injected until _Ready
			_logger.LogInformation("Solution model fully created in {ElapsedMilliseconds} ms", timer.ElapsedMilliseconds);
			await _sharpIdeSolutionService.LoadSolution(solutionModel, path, vsSln, solutionSerializer);
			_sharpIdeSolutionAccessor.SolutionModel = solutionModel;
			_sharpIdeSolutionAccessor.SolutionReadyTcs.SetResult();
			_codeEditorPanel.Solution = solutionModel;
			_searchWindow.Solution = solutionModel;
			_searchAllFilesWindow.Solution = solutionModel;
			_fileExternalChangeHandler.SolutionModel = solutionModel;
			_fileChangedService.SolutionModel = solutionModel;
			_rootFolderModificationService.RootFolder = sharpIdeRootFolder;
			_roslynAnalysis.StartLoadingSolutionInWorkspace(solutionModel);
			_fileWatcher.StartWatching(solutionModel);

			var previousTabs = Singletons.AppState.RecentSlns.Single(s => s.FilePath == solutionModel.FilePath).IdeSolutionState.OpenTabs;
			var filesToOpen = previousTabs
				.Select(s => (solutionModel.AllFiles.GetValueOrDefault(s.FilePath), new SharpIdeFileLinePosition(s.CaretLine, s.CaretColumn), s.IsSelected))
				.Where(s => s.Item1 is not null)
				.OfType<(SharpIdeFile file, SharpIdeFileLinePosition linePosition, bool isSelected)>()
				.ToList();

			_ = Task.GodotRun(async () =>
			{
				// Preserves order of tabs
				foreach (var (file, linePosition, isSelected) in filesToOpen)
				{
					await GodotGlobalEvents.Instance.FileExternallySelected.InvokeParallelAsync(file, linePosition);
				}
				_navigationHistoryService.StartRecording();
				// Select the selected tab
				var selectedFile = filesToOpen.SingleOrDefault(f => f.isSelected);
				// If no tab was selected, select the last one (if any) - occurs e.g. when the user last had a decompiled file open, which we currently don't persist to disk, meaning that all other file will have isSelected false
				if (selectedFile.file is null)
				{
					var firstTab = filesToOpen.LastOrDefault();
					if (firstTab.file is not null) selectedFile = firstTab;
				}
				if (selectedFile.file is not null) await GodotGlobalEvents.Instance.FileExternallySelected.InvokeParallelAsync(selectedFile.file, selectedFile.linePosition);
			});
		});
	}

	public override void _UnhandledKeyInput(InputEvent @event)
	{
		if (@event.IsActionPressed(InputStringNames.FindInFiles))
		{
			AcceptEvent();
			var currentCodeEdit = _codeEditorPanel.GetCurrentCodeEdit();
			if (currentCodeEdit?.HasSelection() is true)
			{
				_searchWindow.SetSearchText(currentCodeEdit.GetSelectedText());
			}

			_searchWindow.Popup();
		}
		else if (@event.IsActionPressed(InputStringNames.FindFiles))
		{
			AcceptEvent();
			_searchAllFilesWindow.Popup();
		}
	}
}
