<h1 align="center">
  <img src="src/SharpIDE.Godot/Resources/SharpIdeV3.svg" alt="SharpIDE icon" width="100" height="100" />
  <br>
  SharpIDE
</h1>

A modern, cross platform & open source IDE for .NET

### Building
See [CONTRIBUTING.md](CONTRIBUTING.md) for instructions for building and running SharpIDE locally!

### WIP
SharpIDE is a WIP, and contributions are always welcome! If you encounter an error, please raise an issue! 😊

### FAQs

<details><summary>SharpIDE won't open on MacOS Tahoe</summary>
Tahoe further restricted users' ability to run unsigned software. Follow these steps to get it running:

1. download a fresh zip of the latest release
2. extract
3. move SharpIDE.app to `Applications`
4. open terminal
5. run `xattr -d -r com.apple.quarantine /Applications/SharpIDE.app`
6. run `sudo codesign --force --deep --sign - /Applications/SharpIDE.app`

if codesign is not installed, install it with `xcode-select --install`
</details>

<img width="1638" height="935" alt="image" src="https://github.com/user-attachments/assets/bce91555-a1f2-43ab-a525-8353b4c7cff2" />

## Completions
<img width="1778" height="973" alt="image" src="https://github.com/user-attachments/assets/92e1c9aa-dad2-4a2f-9f5b-09d97d590a02" />

## Signature Help
<img width="1509" height="873" alt="image" src="https://github.com/user-attachments/assets/fcc95494-dcd1-4c4a-b566-3f9bda95b3a2" />

## Code Action/Refactoring
<img width="1636" height="852" alt="image" src="https://github.com/user-attachments/assets/1448d630-ec5d-4a32-8827-bb78fd27872a" />

## Symbol Info
<img width="1596" height="853" alt="image" src="https://github.com/user-attachments/assets/b5b3f2f7-0b85-4486-a7d2-9c7ed66ab288" />

## Razor Syntax Highlighting
<img width="1619" height="852" alt="image" src="https://github.com/user-attachments/assets/2935f3a3-a5b7-4949-96d6-06f0b5a77d33" />

## Run
<img width="1544" height="867" alt="image" src="https://github.com/user-attachments/assets/53c32fd2-959d-4e72-9e50-83edaa008d8b" />

## Debug
<img width="1513" height="880" alt="image" src="https://github.com/user-attachments/assets/9bd75fef-4198-41a8-a029-c4eea2e53a97" />


## Build
<img width="1544" height="868" alt="image" src="https://github.com/user-attachments/assets/4906de77-f3a7-4dc6-8138-6a824ae3eb61" />

## NuGet (WIP)
<img width="1651" height="1002" alt="image" src="https://github.com/user-attachments/assets/a9f9259e-f733-43ad-a99e-9a932baf6f9d" />

## Test Explorer (WIP)
<img width="1630" height="895" alt="image" src="https://github.com/user-attachments/assets/b76efd8e-6f57-42a4-b2dc-8fd3e907db83" />

## Solution Picker
<img width="842" height="498" alt="image" src="https://github.com/user-attachments/assets/044f0ed3-f679-4fbf-9c3c-c6180bfda7ab" />
